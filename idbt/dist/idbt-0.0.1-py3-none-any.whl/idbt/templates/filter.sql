select * from {{"${table1}"}}
where 
${where_clause}

