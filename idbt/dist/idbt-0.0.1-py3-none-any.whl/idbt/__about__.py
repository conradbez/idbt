# SPDX-FileCopyrightText: 2023-present Conrad <conradbez1@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
