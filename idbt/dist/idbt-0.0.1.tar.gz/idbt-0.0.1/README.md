# idbt

[![PyPI - Version](https://img.shields.io/pypi/v/idbt.svg)](https://pypi.org/project/idbt)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/idbt.svg)](https://pypi.org/project/idbt)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Run

`pipx run poetry shell`

## Installation

```console
pip install idbt
```

## License

`idbt` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
