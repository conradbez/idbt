select * from {{"idbt_select_table"}}
where 
1

