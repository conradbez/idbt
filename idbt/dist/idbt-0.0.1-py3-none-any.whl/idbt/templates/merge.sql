select * from {{"${table1}"}}
left join {{"${table2}"}} 
on 
{{"${merge_col}"}} = {{"${merge_col}"}}